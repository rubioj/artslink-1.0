export { Favoritefilled22 } from "./Favoritefilled22";
