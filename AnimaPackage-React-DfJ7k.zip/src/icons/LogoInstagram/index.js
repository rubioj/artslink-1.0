export { LogoInstagram } from "./LogoInstagram";
