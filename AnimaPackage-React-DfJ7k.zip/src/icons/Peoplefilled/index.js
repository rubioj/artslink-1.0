export { Peoplefilled } from "./Peoplefilled";
