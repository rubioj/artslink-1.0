export { Favoritefilled7 } from "./Favoritefilled7";
