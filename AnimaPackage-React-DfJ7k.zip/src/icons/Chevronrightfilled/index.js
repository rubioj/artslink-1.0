export { Chevronrightfilled } from "./Chevronrightfilled";
