import { LogoInstagramWrapper } from ".";

export default {
  title: "Components/LogoInstagramWrapper",
  component: LogoInstagramWrapper,
};

export const Default = {
  args: {
    className: {},
  },
};
