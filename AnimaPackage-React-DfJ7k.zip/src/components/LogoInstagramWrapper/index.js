export { LogoInstagramWrapper } from "./LogoInstagramWrapper";
