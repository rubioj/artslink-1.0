import { LibraryInstance } from ".";

export default {
  title: "Components/LibraryInstance",
  component: LibraryInstance,
};

export const Default = {
  args: {
    className: {},
  },
};
