import { SlidervalueLabel } from ".";

export default {
  title: "Components/SlidervalueLabel",
  component: SlidervalueLabel,
};

export const Default = {
  args: {
    label: "12",
    active: true,
    className: {},
  },
};
