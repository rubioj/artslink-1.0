import { BottomNavigationWrapper } from ".";

export default {
  title: "Components/BottomNavigationWrapper",
  component: BottomNavigationWrapper,
};

export const Default = {
  args: {
    className: {},
  },
};
