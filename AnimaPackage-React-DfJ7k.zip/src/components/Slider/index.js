export { Slider } from "./Slider";
