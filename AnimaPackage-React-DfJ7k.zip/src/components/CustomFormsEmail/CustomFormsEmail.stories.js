import { CustomFormsEmail } from ".";

export default {
  title: "Components/CustomFormsEmail",
  component: CustomFormsEmail,
};

export const Default = {
  args: {
    className: {},
    formcontrollabelLabelPlacementEndClassName: {},
  },
};
